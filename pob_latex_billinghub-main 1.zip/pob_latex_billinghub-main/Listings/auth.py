SECRET_KEY = os.environ.get("SECRET_KEY")
ALGORITHM = os.environ.get("ALGORITHM")
ACCESS_TOKEN_EXPIRE_IN_MINUTES = int(os.environ.get("ACCESS_TOKEN_EXPIRE_IN_MINUTES"))
DEFAULT_USER_NAME = os.environ.get("DEFAULT_USER_NAME")
DEFAULT_USER_PASSWORD = os.environ.get("DEFAULT_USER_PASSWORD")

pwd_context = CryptContext(schemes=["bcrypt"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/login")


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(secret=plain_password, hash=hashed_password)


def create_access_token(user: User) -> str:
    try:
        claims = {
            "sub": user.username,
            "email": user.email,
            "exp": datetime.datetime.now()
            + datetime.timedelta(minutes=ACCESS_TOKEN_EXPIRE_IN_MINUTES),
        }
        return jwt.encode(claims, key=SECRET_KEY, algorithm=ALGORITHM)
    except JWTError:
        raise HTTPException(
            status_code=401, detail="Error while trying to encode credentials"
        )


def verify_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, key=SECRET_KEY, algorithms=ALGORITHM)
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Could not validate token")


def validate_user(token: str, db: Session) -> User:
    payload = verify_token(token)
    username = payload.get("sub")
    user = db.exec(select(User).where(User.username == username)).first()
    if not user:
        raise HTTPException(status_code=401, detail="Not authorized")
    return user


def get_current_user_token(
    token: str = Depends(oauth2_scheme), db: Session = Depends(get_session)
) -> User:
    return validate_user(token, db)


def get_current_user(request: Request, db: Session = Depends(get_session)):
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=401, detail="Not authorized")
    return validate_user(token, db)


def create_default_user():
    with Session(engine) as db:
        user_exists = db.exec(select(User.username == DEFAULT_USER_NAME)).first()
        if not user_exists:
            default_user = User(
                username=DEFAULT_USER_NAME,
                email="default@user.com",
                password=get_password_hash(DEFAULT_USER_PASSWORD),
            )
            db.add(default_user)
            db.commit()
            print("Default user created")
        else:
            print("User already exists")
