DEFAULT_USER_NAME = os.environ.get("DEFAULT_USER_NAME")


async def create_user(user_model: UserModel, db: Session):
    email_taken = db.exec(select(User).where(User.email == user_model.email)).first()
    if email_taken:
        raise HTTPException(status_code=400, detail="Email already in use")
    username_taken = db.exec(
        select(User).where(User.username == user_model.username)
    ).first()
    if username_taken:
        raise HTTPException(status_code=400, detail="User name already in use")

    user_model.password = get_password_hash(user_model.password)
    user = User.from_orm(user_model)
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"success": f"User with id {user.id} was created"}


async def change_password(
    db: Session,
    username: str = None,
    old_password: str = None,
    new_password: str = None,
):
    user = db.exec(select(User).where(User.username == username)).first()
    print(f"User = {user}")

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if not verify_password(old_password, user.password):
        raise HTTPException(status_code=400, detail="Incorrect password")

    user.password = get_password_hash(new_password)
    db.add(user)
    db.commit()
    db.commit()
    db.refresh(user)
    return {"success": "Password changed successfully"}


async def login_user(
    db: Session,
    form_data: OAuth2PasswordRequestForm = None,
    username: str = None,
    password: str = None,
):
    if form_data:
        username = form_data.username
        password = form_data.password

    if not username or not password:
        raise HTTPException(status_code=400, detail="Username or password is required")

    existing_user = db.exec(select(User).where(User.username == username)).first()

    if not existing_user:
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    if not verify_password(password, existing_user.password):
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    token = create_access_token(user=existing_user)
    return {"access_token": token, "token_type": "bearer"}


def delete_user_cookies(response: Response):
    response.delete_cookie(key="auth_token")


async def delete_user(db: Session, username: str):
    if username == DEFAULT_USER_NAME:
        raise HTTPException(status_code=404, detail="Can't delete default user")

    user = db.exec(select(User).where(User.username == username)).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    db.delete(user)
    db.commit()
    return {"success": "User deleted successfully"}
