stub_user = {"username": "testuser", "token": "testtoken"}


def stub_get_current_user():
    return stub_user


app.dependency_overrides[get_current_user] = stub_get_current_user

client = TestClient(app)


def test_dashboard_endpoint():
    # Arrange
    expected_status_code = 200
    expected_content_type = "text/html; charset=utf-8"
    expected_summary_span = '<span class="ms-2">Summary</span>'
    expected_warnings_span = '<span class="ms-2">Warnings</span>'
    expected_pco_instances_span = '<span class="ms-2">PCO Instances</span>'
    expected_navbar = (
        '<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">'
    )
    expected_footer = '<footer class="footer mt-auto py-3">'

    # Extract specific parts from the expected text
    expected_title = "Dashboard"
    expected_div = '<div class="container-fluid">'

    # Act
    response = client.get("/")

    # Assert
    assert (
        response.status_code == expected_status_code
    ), f"Expected status code {expected_status_code}, but got {response.status_code}"
    assert (
        response.headers["content-type"] == expected_content_type
    ), f"Expected content type {expected_content_type}, but got {response.headers['content-type']}"
    assert (
        expected_title in response.text
    ), f"Expected title '{expected_title}' to be in response, but it was not found"
    assert (
        expected_div in response.text
    ), f"Expected div '{expected_div}' to be in response, but it was not found"
    assert (
        expected_summary_span in response.text
    ), f"Expected 'Summary' span not found in response"
    assert (
        expected_warnings_span in response.text
    ), f"Expected 'Warnings' span not found in response"
    assert (
        expected_pco_instances_span in response.text
    ), f"Expected 'PCO Instances' span not found in response"
    assert expected_navbar in response.text, f"Expected navbar not found in response"
    assert expected_footer in response.text, f"Expected footer not found in response"
