# Source of meta class: https://refactoring.guru/design-patterns/singleton/python/example
class SingletonMeta(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):

        if cls not in cls._instances:
            instance = super().__call__(*args, **kwargs)
            cls._instances[cls] = instance
        return cls._instances[cls]


class Cache(metaclass=SingletonMeta):
    def __init__(self):
        self.expiry_time = timedelta(minutes=5)
        self.cache = {}

    def set_value(self, key, value):
        self.cache[key] = (value, datetime.now())

    def get_value(self, key):
        value, timestamp = self.cache.get(key, (None, None))
        if not value or not timestamp:
            return None
        if datetime.now() - timestamp > self.expiry_time:
            del self.cache[key]
            return None
        return value

    def clear_expired(self):
        for key in list(self.cache.keys()):
            _, timestamp = self.cache[key]
            if datetime.now() - timestamp >= self.expiry_time:
                del self.cache[key]


pco_cache = Cache()
