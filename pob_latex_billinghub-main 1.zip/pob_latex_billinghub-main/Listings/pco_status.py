class InfoCard(ABC):
    def __init__(self):
        self.created = datetime.timestamp()

    @abstractmethod
    def update_element(self):
        pass


class PcoStatus(InfoCard):
    def __init__(self):
        self.date = "NA"
        self.month = "NA"
        self.current_month_day = "NA"
        self.prev_month_day = "NA"
        self.prev_month = "NA"
        self.total_billing_amount = "0"
        self.prev_total_billing_amount = "0"
        self.total_storage_used = "0 "
        self.prev_total_storage_used = "0"
        self.billable_contracts = "0"
        self.prev_billable_contracts = "0"
        self.billing_percentage = "0"
        self.storage_percentage = "0"
        self.contracts_percentage = "0"

    def __update_dates(self):
        # To get values for current month
        datetime_obj = datetime.now()
        current_month_day = datetime_obj.strftime("%d")
        self.date = datetime_obj.strftime(f"%A %d, %B %Y")
        self.month = datetime_obj.strftime("%B")
        self.current_month_day = current_month_day

        # To get values for previous month
        datetime_obj = datetime_obj - relativedelta(months=1)
        prev_month_day = datetime_obj.strftime("%d")
        self.prev_month = datetime_obj.strftime("%B")
        self.prev_month_day = prev_month_day

    def __update_billing_amount(self):
        query = """
        SELECT SUM(value)
        FROM read_parquet('{}')
        """
        int_value = execute_s3_query(query, READY_FOR_AX)[0][0]
        prev_int_value = execute_s3_query(query, READY_FOR_AX, False)[0][0]
        self.total_billing_amount = str(round(int_value))
        self.prev_total_billing_amount = str(round(prev_int_value))

    def __update_storage_used(self):
        query = """
        SELECT SUM(storage)
        FROM read_parquet('{}')
        """
        total = float("{:.2f}".format(execute_s3_query(query, GROUPED_CONTRACTS)[0][0]))
        total = convert_mb_to_tb(total)
        prev_total = float(
            "{:.2f}".format(execute_s3_query(query, GROUPED_CONTRACTS, False)[0][0])
        )
        prev_total = convert_mb_to_tb(prev_total)
        self.total_storage_used = f"{total} TB"
        self.prev_total_storage_used = f"{prev_total} TB"

    def __update_billable_contracts(self):
        query = """
        SELECT COUNT( DISTINCT contractId) 
        FROM read_parquet('{}')
        """
        contracts = execute_s3_query(query, READY_FOR_AX)[0][0]
        prev_contracts = execute_s3_query(query, READY_FOR_AX, False)[0][0]
        self.billable_contracts = str(contracts)
        self.prev_billable_contracts = str(prev_contracts)

    def update_element(self):
        self.__update_billing_amount()
        self.__update_storage_used()
        self.__update_billable_contracts()
        self.__update_dates()
        self.billing_percentage = calculate_percentage(
            transform_string_to_float(self.total_billing_amount),
            transform_string_to_float(self.prev_total_billing_amount),
        )
        self.storage_percentage = calculate_percentage(
            transform_string_to_float(self.total_storage_used),
            transform_string_to_float(self.prev_total_storage_used),
        )
        self.contracts_percentage = calculate_percentage(
            transform_string_to_float(self.billable_contracts),
            transform_string_to_float(self.prev_billable_contracts),
        )