def create_row_data_objects():
    grouped_contracts_data = get_grouped_contracts_data()
    row_objects = [
        PcoRowData(
            contract_id=row[0],
            customer_id=row[1],
            cpu=row[2],
            ram=row[3],
            storage=row[4],
            loadbalancer=row[5],
            ip_addresses=row[6],
            contract_content=[],
        )
        for row in grouped_contracts_data
    ]
    return row_objects


def create_row_data_structures():
    row_objects_list = create_row_data_objects()
    row_objects_dict = {obj.contract_id: obj for obj in row_objects_list}

    for row in get_contracts_classified_data():
        contract_id, customer_id, contract_status, customer_name, product_name = row
        if contract_id in row_objects_dict:
            obj = row_objects_dict[contract_id]
            obj.contract_status = contract_status
            obj.customer_name = customer_name
            obj.product_name = product_name
        else:
            new_row = PcoRowData(
                contract_id=contract_id,
                customer_id=customer_id,
                cpu=0,
                ram=0,
                storage=0,
                loadbalancer=0,
                ip_addresses=0,
                contract_content=[],
                error_msg="",
            )
            new_row.contract_status = contract_status
            new_row.customer_name = customer_name
            new_row.product_name = product_name
            row_objects_dict[contract_id] = new_row
            row_objects_list.append(new_row)

    for row in get_ready_for_ax_data():
        contract_id, billing_usage_type, contract_content_name, value = row
        if contract_id in row_objects_dict:
            obj = row_objects_dict[contract_id]
            obj.contract_content.append(
                {
                    "billing_usage_type": billing_usage_type,
                    "contract_name": contract_content_name,
                    "value": round(value),
                }
            )

    pco_cache.set_value("row_objects_list", row_objects_list)
    print(f"row_objects_list stored in pco_cache")
    pco_cache.set_value("row_objects_dict", row_objects_dict)
    print(f"row_objects_dict stored in pco_cache")
