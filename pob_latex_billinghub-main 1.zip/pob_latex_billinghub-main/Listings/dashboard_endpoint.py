@router.get("/", status_code=200, response_class=HTMLResponse)
async def home(
    request: Request,
    templates: Jinja2Templates = Depends(get_templates),
    current_user: User = Depends(get_current_user),
):
    pco_status = pco_cache.get_value("pco_status")
    pco_warnings = pco_cache.get_value("pco_warnings")
    row_objects_list = pco_cache.get_value("row_objects_list")
    current_month = pco_cache.get_value("current_month")
    last_month = pco_cache.get_value("last_month")
    error_msg_count = pco_cache.get_value("error_msg_count")

    if not pco_status:
        print("Did not find cached pco_status, begin gathering from s3...")
        pco_status = PcoStatus()
        pco_status.update_pco_status()
        pco_cache.set_value("pco_status", pco_status)

    if not pco_warnings:
        print("Did not find cached pco_warnings, begin gathering from s3...")
        pco_warnings = PcoWarnings()
        pco_warnings.update_pco_warnings()
        pco_cache.set_value("pco_warnings", pco_warnings)

    if not row_objects_list or not error_msg_count:
        print("Did not find cached row data structures, begin gathering from s3...")
        create_row_data_structures()
        row_objects_list = pco_cache.get_value("row_objects_list")
        error_msg_count = pco_cache.get_value("error_msg_count")
        current_month = pco_cache.get_value("current_month")
        last_month = pco_cache.get_value("last_month")

    current_month = calendar.month_name[int(current_month)]
    last_month = calendar.month_name[int(last_month)]
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "pco_status": pco_status,
            "pco_warnings": pco_warnings,
            "row_objects_list": row_objects_list,
            "current_user": current_user,
            "error_msg_count": error_msg_count,
            "current_month": current_month,
            "last_month": last_month,
        },
    )


@router.get("/details/{contract_id}", status_code=200, response_class=HTMLResponse)
async def get_details(
    contract_id: str,
    request: Request,
    templates: Jinja2Templates = Depends(get_templates),
    current_user: User = Depends(get_current_user),
):
    row_objects_dict = pco_cache.get_value("row_objects_dict")

    if not row_objects_dict:
        print("Did not find cached row data structures, begin gathering from s3...")
        create_row_data_structures()
        row_objects_dict = pco_cache.get_value("row_objects_dict")

    contract = row_objects_dict.get(contract_id)

    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    return templates.TemplateResponse(
        "details.html",
        {"contract": contract, "request": request, "current_user": current_user},
    )
