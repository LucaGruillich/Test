S3_ENDPOINT = os.environ.get("S3_ENDPOINT")
ACCESS_KEY_ID = os.environ.get("ACCESS_KEY_ID")
SECRET_ACCESS_KEY = os.environ.get("SECRET_ACCESS_KEY")


def get_duckdb_s3_connection():
    con = duckdb.connect()
    con.execute("INSTALL httpfs")
    con.execute("LOAD httpfs")
    con.execute(f"SET s3_endpoint='{S3_ENDPOINT}'")
    con.execute(f"SET s3_access_key_id='{ACCESS_KEY_ID}'")
    con.execute(f"SET s3_secret_access_key='{SECRET_ACCESS_KEY}'")
    return con


def build_s3_path(file_name: str, use_current_month: bool = True):

    datetime_obj = datetime.now()
    if not use_current_month:
        datetime_obj = datetime_obj - relativedelta(months=1)

    year = datetime_obj.year
    month = datetime_obj.month

    base_path = f"s3://rubi-billing/plus-cloud-open/{year}/{month}/"

    if file_name == "raw_data.parquet":
        return f"{base_path}{file_name}"
    day = datetime_obj.day
    file_name = f"{day}-{file_name}"
    return f"{base_path}{file_name}"


def execute_s3_query(
    query: str, file_name: str, use_current_month: bool = True, *args: List[str]
) -> List[Tuple]:
    """
    Executes a SQL query on a .parquet file in S3 storage.

    Args:
        query (str): SQL query to execute, path placeholder must be included as '{}'.
        file_name (str): Name of the .parquet file.
        *args: Optional parameters for the SQL query.
        use_current_month: True gets current months data, false last months

    Returns:
        A list of tuples from the query result.

    Raises:
        HTTPException: If the query execution fails.
    """
    try:
        with get_duckdb_s3_connection() as con:
            path = build_s3_path(file_name, use_current_month)
            if not path:
                raise HTTPException(status_code=400)
            full_query = query.format(path)
            result = con.execute(full_query, *args).fetchall()
            return result
    except duckdb.InvalidInputException as e:
        raise HTTPException(status_code=400, detail=f"Invalid query: {e}")
    except Exception as e:
        print(f"Unexpected error querying data from S3: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")